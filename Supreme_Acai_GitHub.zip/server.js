const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static('public'));

const orders = [];

app.post('/api/orders', (req, res) => {
  const order = {
    id: Date.now(),
    createdAt: new Date().toISOString(),
    status: 'Novo',
    ...req.body
  };
  orders.unshift(order);
  io.emit('order:new', order);
  res.status(201).json(order);
});

app.get('/api/orders', (_req, res) => res.json(orders));

app.patch('/api/orders/:id', (req, res) => {
  const order = orders.find(o => String(o.id) === String(req.params.id));
  if (!order) return res.status(404).json({error: 'Pedido não encontrado'});
  order.status = req.body.status || order.status;
  io.emit('order:update', order);
  res.json(order);
});

io.on('connection', socket => {
  socket.emit('orders:init', orders);
});

server.listen(PORT, () => console.log(`Supreme Açaí online em http://localhost:${PORT}`));

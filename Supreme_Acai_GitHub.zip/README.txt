SUPREME AÇAÍ — ETAPA 4 — PWA

Esta etapa adiciona suporte a Progressive Web App:
- ícone/manifesto de instalação
- abertura em modo aplicativo
- cache básico para carregamento
- botão de instalação
- compatível com acesso por celular

Para publicar:
1. Coloque a pasta em uma hospedagem com HTTPS.
2. Rode o servidor Node.js.
3. Abra o endereço no celular.
4. iPhone: Compartilhar → Adicionar à Tela de Início.
5. Android: menu do navegador → Instalar app.

A etapa 3 continua sendo a base do servidor e dos pedidos em tempo real.
